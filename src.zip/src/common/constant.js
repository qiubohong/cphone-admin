export const DOMAIN = 'http://www.chuangshouji.com/cphone';

export const RECYCLEQUES = [{
    problemName: "",
    problemType:"", 
}];